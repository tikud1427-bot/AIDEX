/**
 * UUS — the Understanding read model.
 *
 * GET /api/aqua/understanding
 *
 * WHAT THIS IS NOT
 * ----------------
 * Not a store, not a profile, not a new source of truth. Every value here is
 * composed from systems that already own it:
 *
 *   Mind          beliefs by dimension, goals
 *   memoryReasoner  gaps → "unknown areas"
 *   coverage.js   the score and per-dimension confidence (pure)
 *
 * Nothing is written. A read that invents storage is how a "dashboard" turns
 * into a second world model that disagrees with the first one.
 *
 * WHY IT IS A SEPARATE ROUTE FROM /mind
 * -------------------------------------
 * `/mind` is the cognitive model's own surface — episodes, predictions, the
 * relationship graph, reflection history. It answers "what is in the Mind".
 * This answers "what does AQUA understand about me", which is a different
 * question with a different audience: one is for debugging, one is the product.
 * Merging them would mean the user-facing screen inherits every field the Mind
 * layer ever adds.
 *
 * Ungated on purpose. It reads what is there; with the flags off it reports a
 * low score honestly rather than 404ing, which is exactly what a new account
 * should see.
 */
import express from 'express';
import { resolveMindOwner, peekMind } from '../mind/mindStore.js';
import { getBeliefs } from '../mind/beliefEngine.js';
import { findGaps } from '../memory/memoryReasoner.js';
import { buildCoverage, COVERAGE_DIMENSIONS } from './coverage.js';

const router = express.Router();

/** Same owner resolution as mindRoutes — deliberately identical, not similar. */
function ownerOf(req) {
  return resolveMindOwner({
    userId: req.aquaUserId ?? null,
    conversationId: req.query.conversationId ?? req.body?.conversationId ?? null,
  });
}

/** Belief shape for the UI: enough to render and to correct, nothing more. */
function publicBelief(b) {
  return {
    ref: `belief:${b.dimension}:${b.key}`,   // what PATCH /understanding/item takes
    dimension: b.dimension,
    key: b.key,
    value: b.value,
    confidence: +Number(b.confidence ?? 0).toFixed(3),
    evidenceCount: b.evidenceCount ?? 0,
    // Provenance is shown, not hidden. "You told me this" and "I worked this
    // out" are different claims, and a trust screen that blurs them is worse
    // than one that shows less.
    source: b.privacy?.source ?? 'inference',
    locked: !!b.privacy?.locked,
    updatedAt: b.updatedAt ?? null,
  };
}

function publicGoal(g) {
  return {
    ref: `goal:${g.id}`,
    id: g.id,
    title: g.title,
    status: g.status,
    confidence: +Number(g.confidence ?? 0).toFixed(3),
    lastMentionedAt: g.lastMentionedAt ?? null,
  };
}

// ── GET /understanding ───────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const ownerId = ownerOf(req);
  if (!ownerId) {
    return res.status(400).json({
      success: false,
      error: 'No owner: log in, or pass ?conversationId= for the dev fallback.',
    });
  }

  const mind = peekMind(ownerId);

  // A brand-new account is the NORMAL case for this endpoint, not an error.
  // 404 would make the first-run gate treat "nothing learned yet" as a failure
  // and hide the very screen that exists to fix it.
  if (!mind) {
    return res.json({
      success: true, ownerId, isNew: true,
      score: 0, confidence: 'nothing yet',
      dimensions: {}, sections: [], goals: [], unknowns: [], sources: [],
      updatedAt: null,
    });
  }

  const beliefsByDimension = {};
  for (const dim of COVERAGE_DIMENSIONS) {
    beliefsByDimension[dim] = getBeliefs(mind, { dimension: dim });
  }
  const goals = Object.values(mind.goals ?? {});

  // Gaps come from the memory reasoner, which owns that question already.
  // Fail-open: a degraded unknowns list is worth far more than a 500 on the
  // screen whose entire job is to make the user feel understood.
  let gaps = {};
  try { gaps = findGaps(ownerId) ?? {}; } catch { /* fail-open */ }

  const coverage = buildCoverage({ beliefsByDimension, goals, gaps });

  // Sections are ordered by what a person would want to read first, not by
  // internal dimension order — and an empty section is DROPPED rather than
  // rendered as "unknown". Three true sentences beat nine padded ones.
  const sections = COVERAGE_DIMENSIONS
    .map(dim => ({
      id: dim,
      label: coverage.dimensions[dim].label,
      confidence: coverage.dimensions[dim].avg,
      confidenceLabel: coverage.dimensions[dim].confidence,
      items: beliefsByDimension[dim].map(publicBelief),
    }))
    .filter(s => s.items.length > 0);

  res.json({
    success: true,
    ownerId,
    isNew: coverage.score === 0,
    score: coverage.score,
    confidence: coverage.confidence,
    dimensions: coverage.dimensions,
    sections,
    goals: goals
      .sort((a, b) => (b.lastMentionedAt ?? 0) - (a.lastMentionedAt ?? 0))
      .map(publicGoal),
    unknowns: coverage.unknowns,
    sources: [
      { kind: 'conversation', count: mind.turnCount ?? 0 },
    ],
    updatedAt: mind.updatedAt ?? null,
  });
});

export default router;
