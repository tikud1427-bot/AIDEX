import { useEffect, useState } from 'react';
import { fetchIntroState, type IntroState } from '@/api/understanding';

/**
 * UUS — the first-run gate.
 *
 * Asks the server once at boot whether this account has ever done the intro.
 * The answer is DERIVED — a conversation marked `understanding_intro` plus a
 * coverage score — not a stored "has onboarded" flag that can end up
 * disagreeing with whether the conversation actually happened.
 *
 * Three rules, all deliberate:
 *
 * NEVER RE-OFFER. Someone who did the intro is never asked again, even if
 * their score is still low. Re-offering reads as "you failed"; understanding
 * grows from ordinary conversation afterwards, which is the design rather
 * than a fallback.
 *
 * DISMISSAL IS LOCAL AND IMMEDIATE. "Not now" hides the offer for this session
 * without a round-trip and without a stored refusal. Someone who declines
 * should not be marked in a database for declining.
 *
 * FAIL CLOSED. If the check fails — offline, cold server, a 500 — the offer
 * does not appear. Erring toward showing it means a returning user could be
 * dropped into an introduction they already did, which is worse than a new
 * user reaching an ordinary empty chat.
 */
export function useUnderstandingGate(conversationId?: string | null) {
  const [state, setState] = useState<IntroState | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    let alive = true;
    fetchIntroState(conversationId)
      .then((s) => { if (alive) setState(s); })
      .catch(() => { /* fail closed — see above */ })
      .finally(() => { if (alive) setChecked(true); });
    return () => { alive = false; };
  }, [conversationId]);

  return {
    /** Show the offer? False until the check returns, so it never flashes. */
    shouldOffer: checked && !dismissed && !!state?.shouldOffer,
    score: state?.score ?? 0,
    hasIntro: state?.hasIntro ?? false,
    checked,
    dismiss: () => setDismissed(true),
  };
}
