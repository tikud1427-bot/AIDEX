#!/usr/bin/env node
/**
 * AQUA test runner.
 *
 * WHY THIS EXISTS
 * ---------------
 * The npm test scripts passed glob patterns straight to `node --test`:
 *
 *     node --test "src/**\/tests/*.test.js"
 *
 * Node only learned to expand those itself in v21. On anything older it treats
 * the pattern as a literal filename and prints
 *
 *     Could not find '/…/aqua/src/**\/tests/*.test.js'
 *
 * …then exits 0 having run NOTHING. Not a crash, not a red suite — a silent
 * zero. Every "1500 tests pass" claim was true on a Node 22 container and
 * completely unverified on the machine that actually ships the code. That is
 * the same failure the dark-test work was meant to end: tests that exist,
 * report nothing, and are believed anyway.
 *
 * Quoting is what breaks it. Unquoted, the SHELL expands `src/mind/tests/*.js`
 * on any system — but `**` needs globstar, which `sh` does not have, so the
 * one script that matters most cannot be fixed that way.
 *
 * So: no globs anywhere. This walks the tree, collects the files, and hands
 * `node --test` an explicit list. Explicit paths have worked since Node 18.
 *
 * It also cannot rot. Adding a directory or a suite requires no edit here and
 * no edit to package.json — discovery is the mechanism, which is what the
 * directory globs were reaching for and could not safely deliver.
 *
 * Usage:
 *   node scripts/run-tests.mjs              # everything under src/
 *   node scripts/run-tests.mjs src/mind     # one area
 *   node scripts/run-tests.mjs --list       # print what would run, run nothing
 */
import { readdirSync, statSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SKIP_DIRS = new Set(['node_modules', '.git', 'coverage', 'dist', 'build']);
const IS_TEST = /\.test\.m?js$/;

function collect(dir, out = []) {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (e.name.startsWith('.') || SKIP_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) collect(full, out);
    else if (IS_TEST.test(e.name)) out.push(full);
  }
  return out;
}

const args = process.argv.slice(2);
const list = args.includes('--list');
const targets = args.filter(a => !a.startsWith('--'));
const roots = (targets.length ? targets : ['src']).map(t => path.resolve(ROOT, t));

for (const r of roots) {
  if (!existsSync(r)) {
    console.error(`run-tests: no such path: ${path.relative(ROOT, r)}`);
    process.exit(1);
  }
}

const files = [...new Set(
  roots.flatMap(r => (statSync(r).isDirectory() ? collect(r) : IS_TEST.test(r) ? [r] : [])),
)].sort();

if (!files.length) {
  // A zero-file run is the exact failure this script exists to prevent, so it
  // is an ERROR, never a quiet success.
  console.error(`run-tests: found no *.test.js under ${roots.map(r => path.relative(ROOT, r)).join(', ')}`);
  process.exit(1);
}

if (list) {
  for (const f of files) console.log(path.relative(ROOT, f));
  console.log(`\n${files.length} test file(s)`);
  process.exit(0);
}

const res = spawnSync(process.execPath, ['--test', ...files], { stdio: 'inherit', cwd: ROOT });
process.exit(res.status ?? 1);
